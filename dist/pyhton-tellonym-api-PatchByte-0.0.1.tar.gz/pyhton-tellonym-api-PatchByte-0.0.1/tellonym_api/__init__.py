class TellonymApi():
    def __init__(self, logging):
        self.logging = logging